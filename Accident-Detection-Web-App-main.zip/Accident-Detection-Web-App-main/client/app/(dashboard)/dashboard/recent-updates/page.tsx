import React from "react";

type Props = {};

export default function RecentUpdates({}: Props) {
  return <div>RecentUpdates</div>;
}
